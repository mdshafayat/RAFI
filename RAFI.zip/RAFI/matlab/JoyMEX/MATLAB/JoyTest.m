function JoyTest
    
    running = 1;
%     NET.addAssembly('System.Speech');
%     Speaker = System.Speech.Synthesis.SpeechSynthesizer;
%     
%     Speaker.Speak ('I am ready to go');

    s= serial('COM16', 'InputBufferSize', 50000); %COM name according to pc
    fopen(s);
    set(s,'BaudRate',57600);
    s.terminator = 'CR';
    
    % Initialize two joysticks
    JoyMEX('init',0);
   
    % Create figure and attach close function
    figure('CloseRequestFcn',@onClose);
    % Create plots
    subplot(2,2,1)
    p1=plot([0],[0],'x'); hold on;
    p2=plot([0],[0],'+r');
    p3=plot([0],[0],'og');
    title(sprintf('Device 0\nAxis'))
    set(gca,'xlim',[-1 1],'ylim',[-1 1]); axis square


    subplot(2,2,3)
    b1=bar(zeros(1,8));
    title('Button States')
    set(gca,'xlim',[0 9],'ylim',[0 1]); axis square

    while(running)
        % Query postion and button state of joystick 1
        [a ab] = JoyMEX(0);
        
        % ab(1:8) 1 if button pressed 0 if not
        %a(1)=1 if right  -1 if left  a(2)=1 if down -1 if up
        
        set(p1,'Xdata',a(1),'Ydata',-a(2));
        set(p2,'Xdata',a(4),'Ydata',-a(5));        
        set(p3,'Xdata',0,'Ydata',a(3));        
        set(b1,'Ydata',ab(1:8));
        
        %setting direction
        
        if ((ab(5)==1) &&(ab(6)==1))
            if ab(1)==1 %%stereo vision
                data=0;
                stereo_main();
            else %%sonar data read
              data=100;  
            end
  
        elseif ((ab(1)==1) &&(ab(6)==1)) %right hand 1
            if a(1)==1
                data=34;
            elseif a(1)==-1
                data=35;
            elseif a(2)==-1
                data=32;
            elseif a(2)==1
                data=33;
            else 
                data=31;
            end
            
        elseif ((ab(2)==1) &&(ab(6)==1)) %right hand 2
            if a(1)==1
                data=39;
            elseif a(1)==-1
                data=40;
            elseif a(2)==-1
                data=37;
            elseif a(2)==1
                data=38;
            else 
                data=36;
            end
            
        elseif ((ab(3)==1) &&(ab(6)==1)) %right hand 3
            if a(1)==1
                data=44;
            elseif a(1)==-1
                data=45;
            elseif a(2)==-1
                data=42;
            elseif a(2)==1
                data=43;
            else 
                data=41;
            end
            
         elseif ((ab(4)==1) &&(ab(6)==1)) %right hand 4
            if a(1)==1
                data=49;
            elseif a(1)==-1
                data=50;
            elseif a(2)==-1
                data=47;
            elseif a(2)==1
                data=48;
            else 
                data=46;
            end
                        
         elseif ((ab(1)==1) &&(ab(7)==1)) %right hand 5
            if a(1)==1
                data=54;
            elseif a(1)==-1
                data=55;
            elseif a(2)==-1
                data=52;
            elseif a(2)==1
                data=53;
            else 
                data=51;
            end
            
         elseif ((ab(1)==1) &&(ab(8)==1)) %head right left
            if a(1)==1
                data=19;
            elseif a(1)==-1
                data=20;
            elseif a(2)==-1
                data=17;
            elseif a(2)==1
                data=18;
            else 
                data=16;
            end
            
         elseif ((ab(4)==1) &&(ab(7)==1)) %dil
            if a(1)==1
                data=29;
            elseif a(1)==-1
                data=30;
            elseif a(2)==-1
                data=27;
            elseif a(2)==1
                data=28;
            else 
                data=26;
            end
        
        
        elseif ab(1)==1 %wheel
            if a(1)==1
                data=83;
            elseif a(1)==-1
                data=84;
            elseif a(2)==-1
                data=81;
            elseif a(2)==1
                data=82;
            else 
                data=0;
            end
            
        elseif ab(2)==1 % left hand 1
            if a(1)==1
                data=59;
            elseif a(1)==-1
                data=60;
            elseif a(2)==-1
                data=57;
            elseif a(2)==1
                data=58;
            else 
                data=56;
            end
            
        elseif ab(3)==1 %left hand 2
            if a(1)==1
                data=64;
            elseif a(1)==-1
                data=65;
            elseif a(2)==-1
                data=62;
            elseif a(2)==1
                data=63;
            else 
                data=61;
            end
            
        elseif ab(4)==1 %left hand 3
            if a(1)==1
                data=69;
            elseif a(1)==-1
                data=70;
            elseif a(2)==-1
                data=67;
            elseif a(2)==1
                data=68;
            else 
                data=66;
            end
            
         elseif ab(5)==1 %left hand 4
            if a(1)==1
                data=74;
            elseif a(1)==-1
                data=75;
            elseif a(2)==-1
                data=72;
            elseif a(2)==1
                data=73;
            else 
                data=71;
            end
            
         elseif ab(6)==1 %left hand 5
            if a(1)==1
                data=79;
            elseif a(1)==-1
                data=80;
            elseif a(2)==-1
                data=77;
            elseif a(2)==1
                data=78;
            else 
                data=76;
            end
            
        elseif ab(7)==1 %neck
            if a(1)==1
                data=14;
            elseif a(1)==-1
                data=15;
            elseif a(2)==-1
                data=12;
            elseif a(2)==1
                data=13;
            else 
                data=11;
            end
            
        elseif ab(8)==1 %head up down
            if a(1)==1
                data=24;
            elseif a(1)==-1
                data=25;
            elseif a(2)==-1
                data=22;
            elseif a(2)==1
                data=23;
            else 
                data=21;
            end
            
          
        else
            data=0;
            
        
        end
        
        
         
        
        fprintf(s,'%s', data);
        
        if data==100
            while s.BytesAvailable==0
            end
                 readasync(s);  
                 out = fscanf(s);
                 out=cast(out,'uint8');
                 front=bitand(bitshift(out,-3),1)
                 back=bitand(bitshift(out,-2),1)
                 left=bitand(bitshift(out,-1),1)
                 right=bitand(bitshift(out,0),1)
           
         
        end

        % Force update of plot
        drawnow
    end
    
    % Clear MEX-file to release joysticks
    clear JoyMEX
    
    function onClose(src,evt)
       % When user tries to close the figure, end the while loop and
       % dispose of the figure
       running = 0;
       delete(src);
    end

    fclose(s);
    delete(s);
end



