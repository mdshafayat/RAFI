
sr = serial('COM6', 'InputBufferSize', 50000);
fopen(sr); 
set(sr,'BaudRate',9600);
sr.terminator = 'CR';

a=1;
while a~=0
    a=input('0 to stop ');
    data_to_send='a';
    fprintf(sr,'%s', data_to_send);
end

fclose(sr);
delete(sr);



       
   
    
