
function rectify_2()
%% Step 1: Read Stereo Image Pair
% Read in two color images of the same scene, which were taken from
% different positions. Then, convert them to grayscale. Colors are not
% required for the matching process.
left='left.jpg';
right='right.jpg';
I1 = im2double(rgb2gray(imread(left)));
I2 = im2double(rgb2gray(imread(right)));

%%
% Display both images side by side. Then, display a color composite
% demonstrating the pixel-wise differences between the images.
cvexShowImagePair(I1, I2, 'I1', 'I2');
cvexShowMatches(I1, I2);
title('Composite Images (Red - Left Image, Cyan - Right Image)');

%%
% There is an obvious offset between the images in orientation and
% position. The goal of rectification is to transform the images, aligning
% them such that corresponding points will appear on the same rows in both
% images.

%% Step 2: Collect Interest Points from Each Image
% The rectification process requires a set of point correspondences between
% the two images. To generate these correspondences, you will collect
% points of interest from both images, and then choose potential matches
% between them. Use |detectSURFFeatures| to find blob-like features in both
% images.
blobs1 = detectSURFFeatures(I1, 'MetricThreshold', 2000);
blobs2 = detectSURFFeatures(I2, 'MetricThreshold', 2000);

cvexShowImagePair(I1, I2, 'Points in I1', 'Points in I2', ...
  'SingleColor', blobs1.Location, blobs2.Location);

%% Step 3: Find Putative Point Correspondences
% Use the |extractFeatures| and |matchFeatures| functions to find putative
% point correspondences. For each blob, compute the SURF feature vectors
% (descriptors).
[features1, validBlobs1] = extractFeatures(I1, blobs1);
[features2, validBlobs2] = extractFeatures(I2, blobs2);

%%
% Use the sum of absolute differences (SAD) metric to determine indices of
% matching features.
indexPairs = matchFeatures(features1, features2, 'Metric', 'SAD', ...
  'MatchThreshold', 5);

%%
% Retrieve locations of matched points for each image
matchedPoints1 = validBlobs1.Location(indexPairs(:,1),:);
matchedPoints2 = validBlobs2.Location(indexPairs(:,2),:);

%%
% Show matching points on top of the composite image, which combines stereo
% images. Notice that most of the matches are correct, but there are still
% some outliers.
cvexShowMatches(I1, I2, matchedPoints1, matchedPoints2, ...
  'Putatively matched points in I1', 'Putatively matched points in I2');

%% Step 4: Remove Outliers Using Geometric Constraint
% Since the distances between the scene and the cameras are significantly
% larger than the offset between the cameras, the disparity is small.
% Therefore, you can use an affine transform to approximate the
% transformation between the images, and by doing so, eliminate a
% substantial number of outliers.
%
% Since the underlying transformation between the images is non-planar, use
% a large distance threshold for computing the affine transform.
gte = vision.GeometricTransformEstimator('PixelDistanceThreshold', 50);
[~, geometricInliers] = step(gte, matchedPoints1, matchedPoints2);

%%
% Display the matched points. Notice that many outliers have been
% eliminated.
refinedPoints1 = matchedPoints1(geometricInliers, :); 
refinedPoints2 = matchedPoints2(geometricInliers, :); 
cvexShowMatches(I1, I2, refinedPoints1, refinedPoints2, ...
  'Geometrically matched points in I1', ...
  'Geometrically matched points in I2');

%% Step 5: Remove Outliers Using Epipolar Constraint
% The correctly matched points must satisfy epipolar constraints. This
% means that a point must lie on the epipolar line determined by its
% corresponding point. You will use the |estimateFundamentalMatrix|
% function to compute the fundamental matrix and find the inliers that meet
% the epipolar constraint.
[fMatrix, epipolarInliers, status] = estimateFundamentalMatrix(...
  refinedPoints1, refinedPoints2, 'Method', 'RANSAC', ...
  'NumTrials', 10000, 'DistanceThreshold', 0.1, 'Confidence', 99.99);
  
if status ~= 0 || isEpipoleInImage(fMatrix, size(I1)) ...
  || isEpipoleInImage(fMatrix', size(I2))
  error(['For the rectification to succeed, the images must have enough '...
    'corresponding points and the epipoles must be outside the images.']);
end

inlierPoints1 = refinedPoints1(epipolarInliers, :);
inlierPoints2 = refinedPoints2(epipolarInliers, :);

cvexShowMatches(I1, I2, inlierPoints1, inlierPoints2, ...
  'Inlier points in I1', 'Inlier points in I2');

%% Step 6: Rectify Images
% Use the |estimateUncalibratedRectification| function to compute the
% rectification transformations. These can be used to transform the images,
% such that the corresponding points will appear on the same rows.
[t1, t2] = estimateUncalibratedRectification(fMatrix, ...
  inlierPoints1, inlierPoints2, size(I2));

%%
% Rectify the images using projective transformations, t1 and t2. Show a
% color composite of the rectified images demonstrating point
% correspondences.
cvexShowMatches(I1, I2, inlierPoints1, inlierPoints2, ...
  'Inlier points in I1', 'Inlier points in I2', t1, t2);

%%
% Crop the overlapping area of the rectified images. You can use red-cyan
% stereo glasses to see the 3D effect.
Irectified = cvexTransformImagePair(I1, t1, I2, t2);
figure, imshow(Irectified);
title('Rectified Stereo Images (Red - Left Image, Cyan - Right Image)');
imwrite(Irectified,'rectified.jpg','jpg')
