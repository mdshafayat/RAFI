function [flag,xy]=msermatching(data1,data2)

data1=rgb2gray(data1);
data2=rgb2gray(data2);

data1=imadjust(data1);
data2=imadjust(data2);

figure
region1 = detectMSERFeatures(data1);
imshow(data1); 
hold on;
plot(region1);
% MSER with SURF feature descriptor
[feature1, valid_points1] = extractFeatures(data1, region1);

figure
region2 = detectMSERFeatures(data2);
imshow(data2); 
hold on;
plot(region2);
% MSER with SURF feature descriptor
[feature2, valid_points2] = extractFeatures(data2, region2);

index_pairs = matchFeatures(feature1, feature2); 
if isempty(index_pairs)==1
    flag=1;
    xy=NaN;

else
    matched_pts1 = valid_points1(index_pairs(:, 1));
    matched_pts2 = valid_points2(index_pairs(:, 2));
    flag=0;
    xy= [matched_pts1; matched_pts2];   
    % Visualize corresponding points
    cvexShowMatches(data1,data2,matched_pts1,matched_pts2); 
end

end