function stereo_dyn()

% global sr;
imaqreset

NET.addAssembly('System.Speech');
Speaker = System.Speech.Synthesis.SpeechSynthesizer;

% sr = serial('COM12', 'InputBufferSize', 50000);
% fopen(sr); 
% set(sr,'BaudRate',9600);
% sr.terminator = 'CR';



    vid1 = videoinput('winvideo',2,'I420_640x480');
    vid2 = videoinput('winvideo',3,'I420_640x480');
    
    % Set video input object properties for this application.
    set(vid1,'TriggerRepeat',Inf);
    set(vid2,'TriggerRepeat',Inf);
    
    vid1.FrameGrabInterval = 1;
    vid2.FrameGrabInterval = 1;
    
    set(vid1,'ReturnedColorSpace','rgb');
    set(vid2,'ReturnedColorSpace','rgb');
    
    set(vid1,'FramesPerTrigger', 1000);
    set(vid2,'FramesPerTrigger', 1000);
    % Start acquiring frames.
    
    start(vid1)
    start(vid2)
    
      preview(vid1)
      preview(vid2)
      
      pause(5)
      input('wait: ')
      data2 = getsnapshot(vid1);
      data2=flipdim(flipdim(data2 ,2),1); 
      
     
%       imshow(data2)
%       data2=flipdim(data2 ,2);
      data1 = getsnapshot(vid2);
      
%       data1=imrotate(data1,90);
%       data2=imrotate(data2,90);
      
      stoppreview(vid1)
      stoppreview(vid2)
      flushdata(vid1);
      flushdata(vid2);
      stop(vid1)
      stop(vid2) 
      
%       data1=enhance(data1);
%       data2=enhance(data2);
      
      imwrite(data1,'left.jpg','jpg')
      imwrite(data2,'right.jpg','jpg')
      
      dynamic_blockmatch(data1,data2)
%       rectification () 
%       rectify_2()
%       stereov(data1,data2)

% matching_main();
% serial_send('d')
% 
% fclose(sr);
% delete(sr);



       
   
    
