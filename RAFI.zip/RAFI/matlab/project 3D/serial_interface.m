function serial_interface(data)

s= serial('COM7', 'InputBufferSize', 50000); %COM name according to pc
fopen(s);
set(s,'BaudRate',1200);
s.terminator = 'CR';

fprintf(s,'%s', data);

fclose(s);
delete(s);

end