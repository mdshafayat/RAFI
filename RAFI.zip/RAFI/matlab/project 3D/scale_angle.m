function [valid,scale_recovered,theta_recovered]=scale_angle(data1,data2)


%% Step 1: Read Image
% Bring an image into the workspace.
original = rgb2gray(data1);
imshow(original);
text(size(original,2),size(original,1)+15, ...
    'working image', ...
    'FontSize',7,'HorizontalAlignment','right');

%% Step 2: Resize and Rotate the Image
distorted = rgb2gray(data2); % Try varying the angle, theta.
figure, imshow(distorted)


%% Step 3: Find Matching Features Between Images
% Detect features in both images.
ptsOriginal  = detectSURFFeatures(original);
ptsDistorted = detectSURFFeatures(distorted);

%%
% Extract feature descriptors.
[featuresIn   validPtsIn]  = extractFeatures(original,  ptsOriginal);
[featuresOut validPtsOut]  = extractFeatures(distorted, ptsDistorted);

%%
% Match features by using their descriptors.
index_pairs = matchFeatures(featuresIn, featuresOut);

%%
% Retrieve locations of corresponding points for each image.
matchedOriginal  = validPtsIn(index_pairs(:,1));
matchedDistorted = validPtsOut(index_pairs(:,2));
if isempty(matchedOriginal)||isempty(matchedDistorted)==1
    valid=0;
    scale_recovered = 0;
    theta_recovered = 0;
    return;
end
valid=1;
%%
% Show point matches. Notice the presence of outliers.
cvexShowMatches(original,distorted,matchedOriginal,matchedDistorted);
title('Putatively matched points (including outliers)');

%% Step 4: Estimate Transformation

geoTransformEst = vision.GeometricTransformEstimator; % defaults to RANSAC

% Configure the System object.
geoTransformEst.Transform = 'Nonreflective similarity';
geoTransformEst.NumRandomSamplingsMethod = 'Desired confidence';
geoTransformEst.MaximumRandomSamples = 1000;
geoTransformEst.DesiredConfidence = 99.8;

[tform_matrix inlierIdx] = step(geoTransformEst, matchedDistorted.Location, ...
    matchedOriginal.Location);

%%
% Display matching point pairs used in the computation of the transformation matrix.
cvexShowMatches(original,distorted,matchedOriginal(inlierIdx),...
    matchedDistorted(inlierIdx),'ptsOriginal','ptsDistorted');
title('Matching points (inliers only)');

tform_matrix = cat(2,tform_matrix,[0 0 1]'); % pad the matrix
Tinv  = inv(tform_matrix);

ss = Tinv(2,1);
sc = Tinv(1,1);
scale_recovered = sqrt(ss*ss + sc*sc)
theta_recovered = atan2(ss,sc)*180/pi

%% Step 6: Recover the Original Image
% Recover the original image by transforming the distorted image.
t = maketform('affine', double(tform_matrix));
D = size(original);
recovered = imtransform(distorted,t,'XData',[1 D(2)],'YData',[1 D(1)]);

%%
% Compare |recovered| to |original| by looking at them side-by-side in a montage.
figure, imshowpair(original,recovered,'montage')
end