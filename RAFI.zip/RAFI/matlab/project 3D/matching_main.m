function matching_main()

data2=imread('left.jpg'); 
% data2=enhance(data2);
% data2=imread('left.jpg'); 
% [flag,xy]=surfmatching(data1,data2);
% [flag,xy]=msermatching(data1,data2)
     
files = dir('database/*.jpg'); %%loading reference image from database
j=size(files,1);
j=j+1;
    
    for i=1:length(files)
        data1=imread(num2str(files(i).name));
        [flag xy]=surfmatching(data1,data2);
%         [flag,xy]=msermatching(data1,data2)
        if flag==0
%             name=strrep(num2str(files(i).name),'.jpg',int2str(j))
%             ims(data2,name)
            j=j+1;
            xy
            i=imcrop(data2,[min(xy(:,1)) min(xy(:,2)) max(xy(:,1))-min(xy(:,1)) max(xy(:,2))-min(xy(:,2))])
            imwrite(i,'left.jpg','jpg');
            data3=imread('right.jpg');
            i=imcrop(data2,[min(xy(:,1))+10 min(xy(:,2)) max(xy(:,1))-min(xy(:,1)) max(xy(:,2))-min(xy(:,2))])
            imwrite(i,'right.jpg','jpg');
            break; 
        end

    end
    
   