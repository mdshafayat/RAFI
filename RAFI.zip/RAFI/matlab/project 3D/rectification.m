
function rectification()

%% Stereo Image Rectification
% Stereo image rectification projects images onto a common image plane in
% such a way that the corresponding points have the same row coordinates.
% This process is useful for stereo vision, because the 2-D stereo
% correspondence problem is reduced to a 1-D problem. As an example, stereo
% image rectification is often used as a pre-processing step for
% <videostereo.html computing disparity> or creating anaglyph images.
%
% This example shows how to use the |estimateFundamentalMatrix|,
% |estimateUncalibratedRectification|, and |detectSURFFeatures| functions
% to compute the rectification of two uncalibrated images, where the camera
% intrinsics are unknown.

left='left.jpg';
right='right.jpg';
cvexRectifyImages(left,right);

