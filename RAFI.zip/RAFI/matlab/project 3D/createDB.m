function createDB()

    imaqreset

    vid1 = videoinput('winvideo',2,'I420_640x480');
    
    % Set video input object properties for this application.
    set(vid1,'TriggerRepeat',Inf);
   
    vid1.FrameGrabInterval = 1;
    
    set(vid1,'ReturnedColorSpace','rgb');
     
    set(vid1,'FramesPerTrigger', 1000);
    
    % Start acquiring frames.
    
    start(vid1)
    preview(vid1)
    a=1;
    files = dir('database/*.jpg'); %%loading reference image from database
    i=size(files,1);
    i=i+1;

     while 1
 
         a=input('include more?0=no, any number= yes:      ');
         if a==0
             break;
         end
          data1 = getsnapshot(vid1);
          name=int2str(i);
          name=strcat(name, '.jpg');
          name=strcat('database/',name);
          imwrite(data1,name,'jpg')
          flushdata(vid1);
          data1=enhance(data1);
          data1=rgb2gray(data1);
          points = detectSURFFeatures(data1);
          figure
          imshow(data1)
          hold on;
          plot(points.selectStrongest(10));
          
          figure
          regions = detectMSERFeatures(data1);
          imshow(data1);
          hold on;
          plot(regions);
          
          i=i+1;
     end
     
      stoppreview(vid1)
      stop(vid1)
      
     

      