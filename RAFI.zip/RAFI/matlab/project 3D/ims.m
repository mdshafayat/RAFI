
function ims(data1,name)
%check and save to database

imname=strcat(name,'.jpg');
imname=strcat('matched\',imname);
figure
imshow(data1)

if exist (imname)==0
    imwrite(data1,imname, 'jpg')
end
