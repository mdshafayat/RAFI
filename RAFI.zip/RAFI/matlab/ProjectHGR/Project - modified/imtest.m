im='Images/Database/1.jpg';
data1=imread(im);
m=im2bw(data1);
imshow(m)

data1(:,:,1)=m(:,:)*255;
data1(:,:,2)=m(:,:)*0;
data1(:,:,3)=m(:,:)*0;
figure
imshow(data1)
initDB();
imwrite(data1,'Images/Inputs/sample/b.jpg', 'jpg')

im='Images/Inputs/sample/b.jpg';

[a results]=hgr(im);

   