function createDB()

imaqreset


    vid1 = videoinput('winvideo',3,'I420_640x480');
    
    % Set video input object properties for this application.
    set(vid1,'TriggerRepeat',Inf);
   
    vid1.FrameGrabInterval = 1;
    
    set(vid1,'ReturnedColorSpace','rgb');
     
    set(vid1,'FramesPerTrigger', 1000);
    
    % Start acquiring frames.
    
    start(vid1)
    preview(vid1)
    a=1;
    files = dir('Images/Database/*.jpg'); %%loading reference image from database
    i=size(files,1);
    i=i+1;

     while 1
 
         a=input('include more?0=no, any number= yes:      ');
         if a==0
             break;
         end
          data1 = getsnapshot(vid1);
          data1=imresize(data1,0.625);
          name=int2str(i);
          name=strcat(name, '.jpg');
          name=strcat('Images/Database/',name);
          imwrite(data1,name,'jpg')
    
          flushdata(vid1);
          i=i+1;
     end
     
      stoppreview(vid1)
      stop(vid1)
      