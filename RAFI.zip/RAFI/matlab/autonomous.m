function autonomous()

%global R C  Tr Tc G D Qr Qc Qv r c

    s= serial('COM16', 'InputBufferSize', 50000); %COM name according to pc
    fopen(s);
    set(s,'BaudRate',57600);
    s.terminator = 'CR';
    
    while (1)
    
        data=100;
        fprintf(s,'%s', data);
            while s.BytesAvailable==0
            end
                 readasync(s);  
                 out = fscanf(s);
                 out=cast(out,'uint8');
                 front=bitand(bitshift(out,-3),1)
                 back=bitand(bitshift(out,-2),1)
                 left=bitand(bitshift(out,-1),1)
                 right=bitand(bitshift(out,0),1)
                 
                 if front==1
                     fprintf(s,'%s',0);
                     fprintf(s,'%s',11);
                     fprintf(s,'%s',16);
                     fprintf(s,'%s',21);
                     stereo_main();
                     
                     fprintf(s,'%s',23);
                     stereo_main();
                     
                     
                 end
                 
                  if left==1
                     fprintf(s,'%s',13);
                     fprintf(s,'%s',16);
                     fprintf(s,'%s',21);
                     stereo_main();
                     
                     fprintf(s,'%s',23);
                     stereo_main();
                     
                  end
                 
                 if right==1
                     fprintf(s,'%s',12);
                     fprintf(s,'%s',16);
                     fprintf(s,'%s',21); 
                     stereo_main();
                     
                     fprintf(s,'%s',23);
                     stereo_main();
                     
                 end
                 
                 if front==0
                     fprintf(s,'%s',81);
                     
                 elseif left==0
                     fprintf(s,'%s',84);
                     pause(2);
                     fprintf(s,'%s',81);
                     
                 elseif right==0
                     fprintf(s,'%s',83);
                     pause(2);
                     fprintf(s,'%s',81);
                     
                 elseif back==0
                     fprintf(s,'%s',82);
                     pause(3);
                     
                 else
                     fprintf(s,'%s',0);
                 end
                 
                 pause(2);
                 fprintf(s,'%s',0);
    end
                 
                 
    fclose(s);
    delete(s);    
    
end
   
% 
%     R=16;
%     C=16;
%     Tr=8;
%     Tc=8;
%     r = [0, -1, 0, 1];
%     c = [-1, 0, 1, 0];
%         
%     G=zeros(R,C,4);
%     D= zeros(R,C);
%     
%     Qr=zeros(4*R*C);
%     Qc=zeros(4*R*C);
%     Qv=zeros(4*R*C);
%     
%     while(1)    
%         for i=1:R 
%             for j=1:C
%                 update(i,j,0,0,1,1);
%             end
%         end
% 
%         SSSP();
%     end
%     
%     
% 
% end
% 
% function SSSP()
% 
% global R C  Tr Tc G D Qr Qc Qv r c
%     qh=1; 
%     qt=1;
%     for i=1:R 
%         for j=1:C
%             D(i,j) = 255;
%         end
%     end
%             Qr(qt) = Tr;
%             Qc(qt) = Tc;
%             Qv(qt) = 0;
%             qt=qt+1;
%     while (qh<qt) 
%         if (D(Qr(qh),Qc(qh))==255) 
%             D(Qr(qh),Qc(qh)) = Qv(qh)
%              for i=1:4
%                 if (G(Qr(qh),Qc(qh),i)~=0) 
%                     Qr(qt) = Qr(qh)+r(i);
%                     Qc(qt) = Qc(qh)+c(i); 
%                     Qv(qt) = Qv(qh)+1;
%                 
%                 if (Qr(qt)>=0 && Qr(qt)<R && Qc(qt)>=0 && Qc(qt)<C && D(Qr(qt),Qc(qt))==255) 
%                     qt=qt+1;
%                 end
%                 
%                 end
%              end
%         end
%                 
%                 
%         qh=qh+1;
%     end
%                
%   end
% 
% 
% 
% 
% 
% 
% 
% 
% 
% function update(r, c, w0,  w1, w2,  w3)
% 
%    global G; 
%     G(r,c,1)=w0;
%     G(r,c,2)=w1;
%     G(r,c,3)=w2;
%     G(r,c,4)=w3;
%     SSSP();
% end