//front sonar PA0 ;sonar0
//back sonar PA1  ;sonar1
//left sonar PA2  ;sonar2
//right sonar PA3 ;sonar3

typedef unsigned int byte;

#define get_tcnt1(x) { (x) = TCNT1L; (x) |= (TCNT1H<<8); }
#define set_tcnt1(x) { TCNT1H = (x)>>8; TCNT1L = (x)&0xff; }
#define US_ERROR 0xFFFF
#define  US_NO_OBSTACLE 0xFFFE

const byte servo_duty_1ms = 64;
const byte servo_duty_1andhalf_ms = 96;
const byte servo_duty_2ms = 128;

const byte gear_duty_100=1216;
const byte gear_duty_50=608;
const byte gear_duty_75=912;
const byte gear_duty_25=304;

const byte dist=4;
const byte servo_inc=4;
const byte gear_inc=121;

char uart_rd;
byte servo_th = 0;
short dir;

/*
byte servo_duty1;        //MOTOR1
byte servo_duty2;        //MOTOR2
byte servo_duty3;        //MOTOR3
byte servo_duty4;        //MOTOR4
byte servo_duty5;        //MOTOR5
byte servo_duty6;        //MOTOR6
byte servo_duty7;        //MOTOR7
byte servo_duty8;       //MOTOR8
byte servo_duty9;       //MOTOR9
byte servo_duty10;      //MOTOR10
byte servo_duty11;      //MOTOR11
byte servo_duty12;      //MOTOR12
byte servo_duty13;      //MOTOR13
byte servo_duty14;      //MOTOR14

byte gear_duty1;        //  MOTOR15
byte gear_duty2;         //  MOTOR16
*/

byte servo_duty1,servo_duty2,servo_duty3,servo_duty4,servo_duty5,servo_duty6,servo_duty7,servo_duty8,servo_duty9,servo_duty10,servo_duty11,servo_duty12,servo_duty13,servo_duty14,gear_duty1,gear_duty2;

byte front, back, right, left;

void servo_signal() org IVT_ADDR_TIMER0_OVF
{
  servo_th++;
  if (servo_th==1216) servo_th = 0;
  
}

void get_sonar_reading(char sonar_id)
{
     SREG_I_bit = 0;
      
      switch  (sonar_id)
      {
       case 0:
       //SONAR INITIALIZATION
            DDRA.B0=1;
            PORTA.B0=0;
            Delay_us(10);
            PORTA.B0=1;
            Delay_us(15);
            PORTA.B0=0;
            Delay_us(20);
            DDRA.B0=0;
            //END OF INITIALIZATION

            while(!PINA.B0);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B0);
            get_tcnt1(front);
            TCCR1B=0x00;
            if (front==US_ERROR)
            {
               front=0;
               break;
            }

             if (front==US_NO_OBSTACLE)
            {
               front=100;
               break;
            }

            front=front/116;
            break;

        case 1:
             //SONAR INITIALIZATION
            DDRA.B1=1;
            PORTA.B1=0;
            Delay_us(10);
            PORTA.B1=1;
            Delay_us(15);
            PORTA.B1=0;
            Delay_us(20);
            DDRA.B1=0;
            //END OF INITIALIZATION

            while(!PINA.B1);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B1);
            get_tcnt1(back);
            TCCR1B=0x00;
             if (back==US_ERROR)
            {
               back=0;
               break;
            }

             if (back==US_NO_OBSTACLE)
            {
               back=100;
               break;
            }
            back=back/116;
            break;

        case 2:
             //SONAR INITIALIZATION
            DDRA.B2=1;
            PORTA.B2=0;
            Delay_us(10);
            PORTA.B2=1;
            Delay_us(15);
            PORTA.B2=0;
            Delay_us(20);
            DDRA.B2=0;
            //END OF INITIALIZATION

            while(!PINA.B2);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B2);
            get_tcnt1(left);
            TCCR1B=0x00;
            if (left==US_ERROR)
            {
               left=0;
               break;
            }

             if (left==US_NO_OBSTACLE)
            {
               left=100;
               break;
            }
            left=left/116;
            break;

         case 3:
             //SONAR INITIALIZATION
            DDRA.B3=1;
            PORTA.B3=0;
            Delay_us(10);
            PORTA.B3=1;
            Delay_us(15);
            PORTA.B3=0;
            Delay_us(20);
            DDRA.B3=0;
            //END OF INITIALIZATION

            while(!PINA.B3);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B3);
            get_tcnt1(right);
            TCCR1B=0x00;
            if (right==US_ERROR)
            {
               right=0;
               break;
            }

             if (right==US_NO_OBSTACLE)
            {
               right=100;
               break;
            }
            right=right/116;
            break;

      }

      SREG_I_bit = 1;
}

void move_forward(){
      PORTB.B0=0;
      PORTB.B1=1;
      PORTB.B2=0;
      PORTB.B3=1;
}

void move_back(){
      PORTB.B0=1;
      PORTB.B1=0;
      PORTB.B2=1;
      PORTB.B3=0;
}

void move_right(){
      PORTB.B0=0;
      PORTB.B1=1;
      PORTB.B2=1;
      PORTB.B3=0;
}

void move_left(){
      PORTB.B0=1;
      PORTB.B1=0;
      PORTB.B2=0;
      PORTB.B3=1;
}

void stop_moving(){
      PORTB.B0=0;
      PORTB.B1=0;
      PORTB.B2=0;
      PORTB.B3=0;
}

int main()
{
  char i,sonar;
  UART1_Init(57600);               // Initialize UART module at 9600 bps
  Delay_ms(100);                  //Wait for UART module to stabilize

  DDRB=0xFF;
  DDRC=0xFF;
  DDRA.B4=DDRA.B5=DDRA.B6=DDRA.B7=1;;

  DDRD.B2=1;
  DDRD.B3=1;
  DDRD.B4=1;
  DDRD.B5=1;
  DDRD.B6=1;
  DDRD.B7=1;

  SREG_I_bit = 1;
  TOIE0_bit = 1;
  TCCR0 = 0b001;

  //servo and gear initialization
  servo_duty1 = servo_duty_1andhalf_ms;
  servo_duty2 = servo_duty_1andhalf_ms;
  servo_duty3 = servo_duty_1andhalf_ms;
  
  servo_duty4 = servo_duty_1andhalf_ms;
  
  servo_duty5 = servo_duty_1andhalf_ms;
  servo_duty6 = servo_duty_1andhalf_ms;
  servo_duty7 = servo_duty_1andhalf_ms;
  servo_duty8 = servo_duty_1andhalf_ms;
  servo_duty9 = servo_duty_1andhalf_ms;
  
  
  servo_duty10 = servo_duty_1andhalf_ms;
  servo_duty11 = servo_duty_1andhalf_ms;
  servo_duty12 = servo_duty_1andhalf_ms;
  servo_duty13 = servo_duty_1andhalf_ms;
  servo_duty14 = servo_duty_1andhalf_ms;
  
  gear_duty1=0;
  gear_duty2=0;
  
  move_forward();
  
  dir=0;

  while (1) {                     // Endless loop

  //HEAD
  PORTC.B4 = ((servo_th) < servo_duty1);       // NECK
  PORTC.B5 = ((servo_th) < servo_duty2);       //  RIGHT-LEFT
  PORTC.B6 = ((servo_th) < servo_duty3);       //  UP-DOWN

  //DIL
  PORTC.B7 = ((servo_th) < servo_duty4);

  //RIGHT HAND
  PORTD.B3 = ((servo_th) < servo_duty5);      //  HAND ROTATE
  PORTD.B4 = ((servo_th) < servo_duty6);      //  HAND UP DOWN
  PORTD.B5 = ((servo_th) < servo_duty7);      //GRIP MOVEMENT
  PORTD.B6 = ((servo_th) < servo_duty8);      //GRIP UP
  PORTD.B7 = ((servo_th) < servo_duty9);     //GRIP DOWN

  //LEFT HAND
  PORTD.B2 = ((servo_th) < servo_duty10);    //  HAND ROTATE
  PORTA.B4 = ((servo_th) < servo_duty11);    //  HAND UP DOWN
  PORTA.B5 = ((servo_th) < servo_duty12);    //GRIP MOVEMENT
  PORTA.B6 = ((servo_th) < servo_duty13);    //BUSKET1
  PORTA.B7 = ((servo_th) < servo_duty14);    //BUSKET2

  // LEFT WHEEL
  PORTC.B0 = ((servo_th) < gear_duty1);

  //RIGHT WHEEL
  PORTC.B1 = ((servo_th) < gear_duty2);

  

  switch (dir){
  case 0: if (front<dist) stop_moving(); else move_forward();
  case 1: if (left<dist) stop_moving(); else move_left();
  case 2: if (back<dist) stop_moving(); else move_back();
  case 3: if (right<dist) stop_moving(); else move_right();
  default: stop_moving();
  
  }
         
   if (UART1_Data_Ready()) {      // If data is received,
     uart_rd = UART1_Read();      // read the received data
     

          if (uart_rd==100) {
             for(i=1;i<4;i++)  {
                get_sonar_reading(i); }
                sonar=((front<dist)<<3) |((back<dist)<<2) |((left<dist)<<1) |(right<dist)  ;
                UART1_Write(sonar);
          }
          
         else{
            if(uart_rd < 41)  {
           //wheel movement
               if (uart_rd < 21)   {
                  if( uart_rd ==3)            //right
                          {
                               dir=3;
                               if (right>dist){
                                move_right();
                                }
                                else   stop_moving();
                          }
                   else if (uart_rd ==4)     //left
                        {
                               dir=1;
                               if  (left>dist){
                                   move_left();
                                }
                                else   stop_moving();
                        }

                   else if (uart_rd ==1)       //forward
                        {
                              dir=0;
                              if  (front>dist){
                                    move_forward();

                                 }
                               else   stop_moving();
                        }

                   else if (uart_rd ==2)   //backward
                        {
                            dir=2;
                            if  (back>dist){
                                     move_back();
                                 }
                            else stop_moving();
                        }

                   else if (uart_rd ==0)    //stop
                        {
                                dir=5;
                                stop_moving();

                        }

                        //duty control -wheel

                   else if (uart_rd ==5)    //set full duty
                        {
                                gear_duty1=gear_duty_100;
                                gear_duty2=gear_duty_100;

                        }
                   else if (uart_rd ==6)    //set half duty
                        {
                                gear_duty1=gear_duty_50;
                                gear_duty2=gear_duty_50;

                        }
                   else if (uart_rd ==7)    //set 75% duty
                        {
                                gear_duty1=gear_duty_75;
                                gear_duty2=gear_duty_75;

                        }
                   else if (uart_rd ==8)    //set 25% duty
                        {
                                gear_duty1=gear_duty_25;
                                gear_duty2=gear_duty_25;

                        }
                   else if (uart_rd ==9)    //increase 10% duty
                        {
                                if ((gear_duty1<(gear_duty_100-gear_inc)) && (gear_duty2<(gear_duty_100-gear_inc))) {
                                  gear_duty1=gear_duty1+gear_inc;
                                  gear_duty2=gear_duty2+gear_inc;
                                }

                        }

                   else if (uart_rd ==10)    //decrease 10% duty
                        {
                                if ((gear_duty1>gear_inc) && (gear_duty2>gear_inc)) {
                                  gear_duty1=gear_duty1-gear_inc;
                                  gear_duty2=gear_duty2-gear_inc;
                                }

                        }

                        // servo duty control -head -1

                    else if (uart_rd ==11)    //set 0 degree
                        {
                                  servo_duty1=servo_duty_1andhalf_ms;
                        }

                   else if (uart_rd ==12)    //set +45 degree
                        {
                                  servo_duty1=servo_duty_2ms;
                        }

                   else if (uart_rd ==13)    //set -45 degree
                        {
                                  servo_duty1=servo_duty_1ms;
                        }

                   else if (uart_rd ==14)    //increase duty
                        {
                                  if (servo_duty1<(servo_duty_2ms-servo_inc))  servo_duty1=servo_duty1+servo_inc;
                        }


                   else if (uart_rd ==15)    //decrease duty
                        {
                                  if (servo_duty1>(servo_duty_1ms+servo_inc)) servo_duty1=servo_duty1-servo_inc;
                        }


                                      // servo duty control -head -2

                    else if (uart_rd ==16)    //set 0 degree
                        {
                                  servo_duty2=servo_duty_1andhalf_ms;
                        }

                   else if (uart_rd ==17)    //set +45 degree
                        {
                                  servo_duty2=servo_duty_2ms;
                        }

                   else if (uart_rd ==18)    //set -45 degree
                        {
                                  servo_duty2=servo_duty_1ms;
                        }

                   else if (uart_rd ==19)    //increase duty
                        {
                                  if (servo_duty2<(servo_duty_2ms-servo_inc))  servo_duty2=servo_duty2+servo_inc;
                        }


                   else if (uart_rd ==20)    //decrease duty
                        {
                                  if (servo_duty2>(servo_duty_1ms+servo_inc)) servo_duty2=servo_duty2-servo_inc;
                        }
                    }
                    else{

                                      // servo duty control -head -3

                    if (uart_rd ==21)    //set 0 degree
                        {
                                  servo_duty3=servo_duty_1andhalf_ms;
                        }

                   else if (uart_rd ==22)    //set +45 degree
                        {
                                  servo_duty3=servo_duty_2ms;
                        }

                   else if (uart_rd ==23)    //set -45 degree
                        {
                                  servo_duty3=servo_duty_1ms;
                        }

                   else if (uart_rd ==24)    //increase duty
                        {
                                  if (servo_duty3<(servo_duty_2ms-servo_inc))  servo_duty3=servo_duty3+servo_inc;
                        }


                   else if (uart_rd ==25)    //decrease duty
                        {
                                  if (servo_duty3>(servo_duty_1ms+servo_inc)) servo_duty3=servo_duty3-servo_inc;
                        }

                                      // servo duty control -dil

                    else if (uart_rd ==26)    //set 0 degree
                        {
                                  servo_duty4=servo_duty_1andhalf_ms;
                        }

                   else if (uart_rd ==27)    //set +45 degree
                        {
                                  servo_duty4=servo_duty_2ms;
                        }

                   else if (uart_rd ==28)    //set -45 degree
                        {
                                  servo_duty4=servo_duty_1ms;
                        }

                   else if (uart_rd ==29)    //increase duty
                        {
                                  if (servo_duty4<(servo_duty_2ms-servo_inc))  servo_duty4=servo_duty4+servo_inc;
                        }


                   else if (uart_rd ==30)    //decrease duty
                        {
                                  if (servo_duty4>(servo_duty_1ms+servo_inc)) servo_duty4=servo_duty4-servo_inc;
                        }

                                      // servo duty control -right hand- hand rotate

                    else if (uart_rd ==31)    //set 0 degree
                        {
                                  servo_duty5=servo_duty_1andhalf_ms;
                        }



                    else if (uart_rd ==32)    //set +45 degree
                          {
                                    servo_duty5=servo_duty_2ms;
                          }


                    else if (uart_rd ==33)    //set -45 degree
                          {
                                    servo_duty5=servo_duty_1ms;
                          }

                     else if (uart_rd ==34)    //increase duty
                          {
                                    if (servo_duty5<(servo_duty_2ms-servo_inc))  servo_duty5=servo_duty5+servo_inc;
                          }


                     else if (uart_rd ==35)    //decrease duty
                          {
                                    if (servo_duty5>(servo_duty_1ms+servo_inc)) servo_duty5=servo_duty5-servo_inc;
                          }

                                        // servo duty control -right hand- hand updown

                      else if (uart_rd ==36)    //set 0 degree
                          {
                                    servo_duty6=servo_duty_1andhalf_ms;
                          }

                     else if (uart_rd ==37)    //set +45 degree
                          {
                                    servo_duty6=servo_duty_2ms;
                          }

                     else if (uart_rd ==38)    //set -45 degree
                          {
                                    servo_duty6=servo_duty_1ms;
                          }

                     else if (uart_rd ==39)    //increase duty
                          {
                                    if (servo_duty6<(servo_duty_2ms-servo_inc))  servo_duty6=servo_duty6+servo_inc;
                          }


                     else if (uart_rd ==40)    //decrease duty
                          {
                                    if (servo_duty6>(servo_duty_1ms+servo_inc)) servo_duty6=servo_duty6-servo_inc;
                          }
                       }//endif uart_rd<21

                    }
                    else {
                                        // servo duty control -right hand- grip movement
                     if (uart_rd<61)  {
                     
                      if (uart_rd ==41)    //set 0 degree
                          {
                                    servo_duty7=servo_duty_1andhalf_ms;
                          }

                     else if (uart_rd ==42)    //set +45 degree
                          {
                                    servo_duty7=servo_duty_2ms;
                          }

                     else if (uart_rd ==43)    //set -45 degree
                          {
                                    servo_duty7=servo_duty_1ms;
                          }

                     else if (uart_rd ==44)    //increase duty
                          {
                                    if (servo_duty7<(servo_duty_2ms-servo_inc))  servo_duty7=servo_duty7+servo_inc;
                          }


                     else if (uart_rd ==45)    //decrease duty
                          {
                                    if (servo_duty7>(servo_duty_1ms+servo_inc)) servo_duty7=servo_duty7-servo_inc;
                          }


                                            // servo duty control -right hand- grip up

                      else if (uart_rd ==46)    //set 0 degree
                          {
                                    servo_duty8=servo_duty_1andhalf_ms;
                          }

                     else if (uart_rd ==47)    //set +45 degree
                          {
                                    servo_duty8=servo_duty_2ms;
                          }

                     else if (uart_rd ==48)    //set -45 degree
                          {
                                    servo_duty8=servo_duty_1ms;
                          }

                     else if (uart_rd ==49)    //increase duty
                          {
                                    if (servo_duty8<(servo_duty_2ms-servo_inc))  servo_duty8=servo_duty8+servo_inc;
                          }


                     else if (uart_rd ==50)    //decrease duty
                          {
                                    if (servo_duty8>(servo_duty_1ms+servo_inc)) servo_duty8=servo_duty8-servo_inc;
                          }

                                            // servo duty control -right hand- grip down

                      else if (uart_rd ==51)    //set 0 degree
                          {
                                    servo_duty9=servo_duty_1andhalf_ms;
                          }

                     else if (uart_rd ==52)    //set +45 degree
                          {
                                    servo_duty9=servo_duty_2ms;

                          }
                     else if (uart_rd ==53)    //set -45 degree
                          {
                                    servo_duty9=servo_duty_1ms;
                          }
                     else if (uart_rd ==54)    //increase duty
                          {
                                    if (servo_duty9<(servo_duty_2ms-servo_inc))  servo_duty9=servo_duty9+servo_inc;
                          }

                     else if (uart_rd ==55)    //decrease duty
                          {
                                    if (servo_duty9>(servo_duty_1ms+servo_inc)) servo_duty9=servo_duty9-servo_inc;
                          }
                                                      // servo duty control -left hand- hand rotate

                     else if (uart_rd ==56)    //set 0 degree
                          {
                                    servo_duty10=servo_duty_1andhalf_ms;
                          }

                     else if (uart_rd ==57)    //set +45 degree
                          {
                                    servo_duty10=servo_duty_2ms;
                          }
                     else if (uart_rd ==58)    //set -45 degree
                          {
                                    servo_duty10=servo_duty_1ms;
                          }
                     else if (uart_rd ==59)    //increase duty
                          {
                                    if (servo_duty10<(servo_duty_2ms-servo_inc))  servo_duty10=servo_duty10+servo_inc;
                          }

                     else if (uart_rd ==60)    //decrease duty
                          {
                                    if (servo_duty10>(servo_duty_1ms+servo_inc)) servo_duty10=servo_duty10-servo_inc;
                          }
                       }
                     else{
                                        // servo duty control -left hand- hand updown

                      if (uart_rd ==61)    //set 0 degree
                          {
                                   servo_duty11=servo_duty_1andhalf_ms;
                          }
                     else if (uart_rd ==62)    //set +45 degree
                          {
                                    servo_duty11=servo_duty_2ms;
                          }
                     else if (uart_rd ==63)    //set -45 degree
                          {
                                    servo_duty11=servo_duty_1ms;
                          }
                     else if (uart_rd ==64)    //increase duty
                          {
                                    if (servo_duty11<(servo_duty_2ms-servo_inc))  servo_duty11=servo_duty11+servo_inc;
                          }

                     else if (uart_rd ==65)    //decrease duty
                          {
                                    if (servo_duty11>(servo_duty_1ms+servo_inc)) servo_duty11=servo_duty11-servo_inc;
                          }

                                        // servo duty control -left hand- grip movement

                     else if (uart_rd ==66)    //set 0 degree
                          {
                                    servo_duty12=servo_duty_1andhalf_ms;
                          }
                     else if (uart_rd ==67)    //set +45 degree
                          {
                                    servo_duty12=servo_duty_2ms;
                          }
                     else if (uart_rd ==68)    //set -45 degree
                          {
                                    servo_duty12=servo_duty_1ms;
                          }
                     else if (uart_rd ==69)    //increase duty
                          {
                                    if (servo_duty12<(servo_duty_2ms-servo_inc))  servo_duty12=servo_duty12+servo_inc;
                          }

                     else if (uart_rd ==70)    //decrease duty
                          {
                                    if (servo_duty12>(servo_duty_1ms+servo_inc)) servo_duty12=servo_duty12-servo_inc;
                          }

                                            // servo duty control -left hand- grip up

                     else if (uart_rd ==71)    //set 0 degree
                          {
                                    servo_duty13=servo_duty_1andhalf_ms;
                          }

                    else if (uart_rd ==72)    //set +45 degree
                          {
                                    servo_duty13=servo_duty_2ms;
                          }

                     else if (uart_rd ==73)    //set -45 degree
                          {
                                    servo_duty13=servo_duty_1ms;
                          }

                     else if (uart_rd ==74)    //increase duty
                          {
                                    if (servo_duty13<(servo_duty_2ms-servo_inc))  servo_duty13=servo_duty13+servo_inc;
                          }

                     else if (uart_rd ==75)    //decrease duty
                          {
                                    if (servo_duty13>(servo_duty_1ms+servo_inc)) servo_duty13=servo_duty13-servo_inc;
                          }
                                            // servo duty control -left hand- grip down

                      else if (uart_rd ==76)    //set 0 degree
                          {
                                    servo_duty14=servo_duty_1andhalf_ms;
                          }

                     else if (uart_rd ==77)    //set +45 degree
                          {
                                    servo_duty14=servo_duty_2ms;
                          }

                     else if (uart_rd ==78)    //set -45 degree
                          {
                                    servo_duty14=servo_duty_1ms;
                          }

                     else if (uart_rd ==79)    //increase duty
                          {
                                    if (servo_duty14<(servo_duty_2ms-servo_inc))  servo_duty14=servo_duty14+servo_inc;
                          }

                     else if (uart_rd ==80)    //decrease duty
                          {
                                    if (servo_duty14>(servo_duty_1ms+servo_inc)) servo_duty14=servo_duty14-servo_inc;
                          }

                     else if (uart_rd ==81)
                          {
                               move_forward();
                               gear_duty1=gear_duty_50;
                               gear_duty2=gear_duty_50;
                           }

                     else if (uart_rd ==82)
                          {
                               move_back();
                               gear_duty1=gear_duty_50;
                               gear_duty2=gear_duty_50;
                           }

                     else if (uart_rd ==83)
                          {
                               move_right();
                               gear_duty1=gear_duty_50;
                               gear_duty2=gear_duty_50;
                           }

                     else if (uart_rd ==84)
                          {
                               move_left();
                               gear_duty1=gear_duty_50;
                               gear_duty2=gear_duty_50;
                           }
                           
                          }//endif uart_rd<61
                     
                     } //endif uart_rd<41


               }      //endif uart_rd==100
               
     }  //end if uart_rd
     
    
  }     //endwhile
  
  return 0;
  
}       //endmain