//front sonar PA0 ;sonar0
//back sonar PA1  ;sonar1
//left sonar PA2  ;sonar2
//right sonar PA3 ;sonar3

typedef unsigned int byte;

#define get_tcnt1(x) { (x) = TCNT1L; (x) |= (TCNT1H<<8); }
#define set_tcnt1(x) { TCNT1H = (x)>>8; TCNT1L = (x)&0xff; }
#define US_ERROR 0xFFFF
#define  US_NO_OBSTACLE 0xFFFE

const byte servo_duty_1ms = 64;
const byte servo_duty_1andhalf_ms = 96;
const byte servo_duty_2ms = 128;

const byte gear_duty_100=1216;
const byte gear_duty_50=608;
const byte gear_duty_75=912;
const byte gear_duty_25=304;

const byte dist=2;
const byte servo_inc=1;
const byte gear_inc=121;

char uart_rd;
byte servo_th = 0;
short dir;

/*
byte servo_duty1;        //MOTOR1
byte servo_duty2;        //MOTOR2
byte servo_duty3;        //MOTOR3
byte servo_duty4;        //MOTOR4
byte servo_duty5;        //MOTOR5
byte servo_duty6;        //MOTOR6
byte servo_duty7;        //MOTOR7
byte servo_duty8;       //MOTOR8
byte servo_duty9;       //MOTOR9
byte servo_duty10;      //MOTOR10
byte servo_duty11;      //MOTOR11
byte servo_duty12;      //MOTOR12
byte servo_duty13;      //MOTOR13
byte servo_duty14;      //MOTOR14

byte gear_duty1;        //  MOTOR15
byte gear_duty2;         //  MOTOR16
byte gear_duty3;          //  MOTOR17
byte gear_duty4;          //  MOTOR18 */

byte servo_duty1,servo_duty2,servo_duty3,servo_duty4,servo_duty5,servo_duty6,servo_duty7,servo_duty8,servo_duty9,servo_duty10,servo_duty11,servo_duty12,servo_duty13,servo_duty14,gear_duty1,gear_duty2,gear_duty3,gear_duty4;

byte front, back, right, left;

void servo_signal() org IVT_ADDR_TIMER0_OVF
{
  servo_th++;
  if (servo_th==1216) servo_th = 0;

}

void get_sonar_reading(char sonar_id)
{
     SREG_I_bit = 0;

      switch  (sonar_id)
      {
       case 0:
       //SONAR INITIALIZATION
            DDRA.B0=1;
            PORTA.B0=0;
            Delay_us(10);
            PORTA.B0=1;
            Delay_us(15);
            PORTA.B0=0;
            Delay_us(20);
            DDRA.B0=0;
            //END OF INITIALIZATION

            while(!PINA.B0);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B0);
            get_tcnt1(front);
            TCCR1B=0x00;
            if (front==US_ERROR)
            {
               front=0;
               break;
            }

             if (front==US_NO_OBSTACLE)
            {
               front=100;
               break;
            }

            front=front/116;
            break;

        case 1:
             //SONAR INITIALIZATION
            DDRA.B1=1;
            PORTA.B1=0;
            Delay_us(10);
            PORTA.B1=1;
            Delay_us(15);
            PORTA.B1=0;
            Delay_us(20);
            DDRA.B1=0;
            //END OF INITIALIZATION

            while(!PINA.B1);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B1);
            get_tcnt1(back);
            TCCR1B=0x00;
             if (back==US_ERROR)
            {
               back=0;
               break;
            }

             if (back==US_NO_OBSTACLE)
            {
               back=100;
               break;
            }
            back=back/116;
            break;

        case 2:
             //SONAR INITIALIZATION
            DDRA.B2=1;
            PORTA.B2=0;
            Delay_us(10);
            PORTA.B2=1;
            Delay_us(15);
            PORTA.B2=0;
            Delay_us(20);
            DDRA.B2=0;
            //END OF INITIALIZATION

            while(!PINA.B2);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B2);
            get_tcnt1(left);
            TCCR1B=0x00;
            if (left==US_ERROR)
            {
               left=0;
               break;
            }

             if (left==US_NO_OBSTACLE)
            {
               left=100;
               break;
            }
            left=left/116;
            break;

         case 3:
             //SONAR INITIALIZATION
            DDRA.B3=1;
            PORTA.B3=0;
            Delay_us(10);
            PORTA.B3=1;
            Delay_us(15);
            PORTA.B3=0;
            Delay_us(20);
            DDRA.B3=0;
            //END OF INITIALIZATION

            while(!PINA.B3);
            TCCR1A=0x00;
            TCCR1B=(1<<CS11);
            set_tcnt1(0);

            while(PINA.B3);
            get_tcnt1(right);
            TCCR1B=0x00;
            if (right==US_ERROR)
            {
               right=0;
               break;
            }

             if (right==US_NO_OBSTACLE)
            {
               right=100;
               break;
            }
            right=right/116;
            break;

      }

      SREG_I_bit = 1;
}

void move_forward(){
      PORTB.B0=0;
      PORTB.B1=1;
      PORTB.B2=0;
      PORTB.B3=1;
}

void move_back(){
      PORTB.B0=1;
      PORTB.B1=0;
      PORTB.B2=1;
      PORTB.B3=0;
}

void move_right(){
      PORTB.B0=0;
      PORTB.B1=1;
      PORTB.B2=1;
      PORTB.B3=0;
}

void move_left(){
      PORTB.B0=1;
      PORTB.B1=0;
      PORTB.B2=0;
      PORTB.B3=1;
}

void stop_moving(){
      PORTB.B0=0;
      PORTB.B1=0;
      PORTB.B2=0;
      PORTB.B3=0;
}

int main()
{
  int i;
  UART1_Init(57600);               // Initialize UART module at 9600 bps
  Delay_ms(100);                  //Wait for UART module to stabilize

  DDRB=0xFF;
  DDRC=0xFF;
  DDRA.B4=DDRA.B5=DDRA.B6=DDRA.B7=1;;

  DDRD.B2=1;
  DDRD.B3=1;
  DDRD.B4=1;
  DDRD.B5=1;
  DDRD.B6=1;
  DDRD.B7=1;

  SREG_I_bit = 1;
  TOIE0_bit = 1;
  TCCR0 = 0b001;

  //servo and gear initialization
  servo_duty1 = servo_duty_1andhalf_ms;
  servo_duty2 = servo_duty_1andhalf_ms;
  servo_duty3 = servo_duty_1andhalf_ms;

  servo_duty4 = servo_duty_1andhalf_ms;

  servo_duty5 = servo_duty_1andhalf_ms;
  servo_duty6 = servo_duty_1andhalf_ms;
  servo_duty7 = servo_duty_1andhalf_ms;
  servo_duty8 = servo_duty_1andhalf_ms;
  servo_duty9 = servo_duty_1andhalf_ms;


  servo_duty10 = servo_duty_1andhalf_ms;
  servo_duty11 = servo_duty_1andhalf_ms;
  servo_duty12 = servo_duty_1andhalf_ms;
  servo_duty13 = servo_duty_1andhalf_ms;
  servo_duty14 = servo_duty_1andhalf_ms;

  gear_duty1=0;
  gear_duty2=0;
  gear_duty3=0;
  gear_duty4=0;

  move_forward();

    //LEFT HAND FORWARD
  PORTB.B4=1;
  PORTB.B5=0;

  //RIGHT HAND FORWARD
  PORTB.B6=1;
  PORTB.B7=0;

  dir=0;

  while (1) {                     // Endless loop

  //HEAD
  PORTC.B4 = ((servo_th) < servo_duty1);       // NECK
  PORTC.B5 = ((servo_th) < servo_duty2);       //  RIGHT-LEFT
  PORTC.B6 = ((servo_th) < servo_duty3);       //  UP-DOWN

  //DIL
  PORTC.B7 = ((servo_th) < servo_duty4);

  //RIGHT HAND
  PORTD.B3 = ((servo_th) < servo_duty5);      //  HAND ROTATE
  PORTD.B4 = ((servo_th) < servo_duty6);      //  HAND UP DOWN
  PORTD.B5 = ((servo_th) < servo_duty7);      //GRIP MOVEMENT
  PORTD.B6 = ((servo_th) < servo_duty8);      //GRIP UP
  PORTD.B7 = ((servo_th) < servo_duty9);     //GRIP DOWN

  //LEFT HAND
  PORTD.B2 = ((servo_th) < servo_duty10);    //  HAND ROTATE
  PORTA.B4 = ((servo_th) < servo_duty11);    //  HAND UP DOWN
  PORTA.B5 = ((servo_th) < servo_duty12);    //GRIP MOVEMENT
  PORTA.B6 = ((servo_th) < servo_duty13);    //BUSKET1
  PORTA.B7 = ((servo_th) < servo_duty14);    //BUSKET2

  // LEFT WHEEL
  PORTC.B0 = ((servo_th) < gear_duty1);

  //RIGHT WHEEL
  PORTC.B1 = ((servo_th) < gear_duty2);

  // LEFT HAND
  PORTC.B2 = ((servo_th) < gear_duty3);

  //RIGHT HAND
  PORTC.B3 = ((servo_th) < gear_duty4);


   if (UART1_Data_Ready()) {      // If data is received,
     uart_rd = UART1_Read();      // read the received data

       //wheel movement
               if (uart_rd ==99)
                    {
                         move_forward();
                         gear_duty1=gear_duty_50;
                         gear_duty2=gear_duty_50;
                     }
               else if (uart_rd ==100)
                    {
                         move_back();
                         gear_duty1=gear_duty_50;
                         gear_duty2=gear_duty_50;
                     }
               else if (uart_rd ==101)
                    {
                         move_right();
                         gear_duty1=gear_duty_50;
                         gear_duty2=gear_duty_50;
                     }
               else if (uart_rd ==102)
                    {
                         move_left();
                         gear_duty1=gear_duty_50;
                         gear_duty2=gear_duty_50;
                     }
               else if (uart_rd ==103)
                    {
                         stop_moving();

                     }

               else if (uart_rd ==104)     //forward
                    {
                         PORTB.B4=1;
                         PORTB.B5=0;

                         PORTB.B6=0;
                         PORTB.B7=0;
                         gear_duty3=gear_duty_50;

                     }
               else if (uart_rd ==105)    //reverse
                    {
                         PORTB.B4=0;
                         PORTB.B5=1;

                         PORTB.B6=0;
                         PORTB.B7=0;
                         gear_duty3=gear_duty_50;


                     }
               else if (uart_rd ==106)  //forward
                    {
                         PORTB.B6=1;
                         PORTB.B7=0;

                         PORTB.B4=0;
                         PORTB.B5=0;

                         gear_duty4=gear_duty_50;

                     }
               else if (uart_rd ==107)    //reverse
                    {
                         PORTB.B6=0;
                         PORTB.B7=1;

                         PORTB.B4=0;
                         PORTB.B5=0;
                         gear_duty4=gear_duty_50;

                     }


        }
        
        }
  return 0;
}