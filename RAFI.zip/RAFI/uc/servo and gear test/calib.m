s= serial('COM16', 'InputBufferSize', 50000); %COM name according to pc
fopen(s);
set(s,'BaudRate',57600);
s.terminator = 'CR';

t=input('runtime in seconds :    ');

data=3; %right
fprintf(s,'%s', data);

pause(t); %number of seconds to be delayed

data=0; %stop
fprintf(s,'%s', data);

fclose(s);
delete(s);

